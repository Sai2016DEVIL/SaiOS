#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
: "${ANDROID_MANIFEST_URL:=https://github.com/LineageOS/android.git}"
: "${ANDROID_BRANCH:=cm-13.0}"
if [ -d .repo ]; then
  echo '.repo already exists; syncing'
else
  repo init -u "$ANDROID_MANIFEST_URL" -b "$ANDROID_BRANCH" --depth=1
fi
repo sync -c --force-sync --no-clone-bundle --no-tags
mkdir -p device/samsung kernel/samsung vendor/samsung
candidates=(
  "https://github.com/CyanogenMod/android_device_samsung_arubaslim.git"
  "https://github.com/LineageOS/android_device_samsung_arubaslim.git"
  "https://github.com/efex09/android_device_samsung_arubaslim.git"
)
for url in "${candidates[@]}"; do
  if git ls-remote "$url" HEAD >/dev/null 2>&1; then
    git clone --depth=1 "$url" device/samsung/arubaslim.upstream
    break
  fi
done
if [ ! -d device/samsung/arubaslim.upstream ]; then
  echo 'ERROR: no exact arubaslim device tree found at the known public candidates.' >&2
  exit 2
fi
