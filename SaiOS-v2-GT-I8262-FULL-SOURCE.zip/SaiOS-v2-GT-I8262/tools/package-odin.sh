#!/bin/bash
set -euo pipefail
OUT=out/target/product/arubaslim
[ -f "$OUT/recovery.img" ] || { echo 'No verified recovery.img; refusing to create an Odin package.' >&2; exit 2; }
mkdir -p dist
cp "$OUT/recovery.img" dist/SaiOS-v2-recovery-GT-I8262.img
# This intentionally does not invent a PIT, modem, bootloader, CSC, or Odin tar.
