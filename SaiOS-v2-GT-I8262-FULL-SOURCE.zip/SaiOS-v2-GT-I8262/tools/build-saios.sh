#!/bin/bash
set -euo pipefail
source build/envsetup.sh
lunch saios_arubaslim-userdebug
mka bacon
OUT=out/target/product/arubaslim
mkdir -p "$OUT/saios-package"
cp -f "$OUT"/*saios*.zip "$OUT/saios-package/" 2>/dev/null || true
