#!/bin/bash
set -euo pipefail
[ -f VERSION ] || exit 1
[ -f device/samsung/arubaslim/BoardConfig.mk ] || exit 2
grep -q 'TARGET_BOOTLOADER_BOARD_NAME := arubaslim' device/samsung/arubaslim/BoardConfig.mk
grep -q 'TARGET_BOARD_PLATFORM := msm8225' device/samsung/arubaslim/BoardConfig.mk
echo 'Target checks passed: GT-I8262 / arubaslim / MSM8225 / ARMv7'
