Do not place random GT-I8260/I8262 firmware here. Only use files verified for GT-I8262/arubaslim.
Required proprietary modem/RIL files must come from a legally obtained device firmware dump or compatible vendor package. The build cannot safely fabricate them.
