The Android CM13 build expects kernel/samsung/arubaslim from the exact device source. This directory is deliberately not populated with a random kernel binary.
