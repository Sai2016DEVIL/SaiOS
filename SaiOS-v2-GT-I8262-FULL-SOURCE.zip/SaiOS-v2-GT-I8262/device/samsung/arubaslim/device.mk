LOCAL_PATH := $(call my-dir)

PRODUCT_AAPT_CONFIG := normal mdpi
PRODUCT_AAPT_PREF_CONFIG := mdpi
PRODUCT_LOCALES := en_GB

# SaiOS overlay
PRODUCT_PACKAGE_OVERLAYS += $(LOCAL_PATH)/../../../overlay
