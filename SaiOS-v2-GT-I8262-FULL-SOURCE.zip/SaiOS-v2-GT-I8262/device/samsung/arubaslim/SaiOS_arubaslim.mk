$(call inherit-product, device/samsung/arubaslim/device.mk)
$(call inherit-product, vendor/saios/config/common.mk)

PRODUCT_NAME := saios_arubaslim
PRODUCT_DEVICE := arubaslim
PRODUCT_BRAND := SaiOS
PRODUCT_MODEL := SaiOS Galaxy Core
PRODUCT_MANUFACTURER := Samsung
PRODUCT_CHARACTERISTICS := default
