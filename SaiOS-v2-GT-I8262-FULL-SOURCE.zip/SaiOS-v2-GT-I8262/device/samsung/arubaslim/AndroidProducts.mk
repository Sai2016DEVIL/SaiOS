PRODUCT_MAKEFILES := $(LOCAL_DIR)/SaiOS_arubaslim.mk
COMMON_LUNCH_CHOICES := saios_arubaslim-userdebug
