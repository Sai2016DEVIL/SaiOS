# Building SaiOS v2

1. Use a Linux x86_64 host.
2. Install Git, Python 2.7-compatible tooling where required by the legacy tree, Java 7/8 as appropriate for the chosen CM13/Lineage 13 tree, GNU build tools, and the Android build dependencies.
3. Run `./tools/fetch-sources.sh`.
4. Run `source build/envsetup.sh`.
5. Run `lunch saios_arubaslim-userdebug`.
6. Run `./tools/build-saios.sh`.
7. Check `out/target/product/arubaslim/` for the ROM ZIP and recovery image.

If the source fetch cannot find an exact arubaslim tree, the script stops. It never substitutes I8260, another Samsung device, or a generic kernel.
