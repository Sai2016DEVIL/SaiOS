# Known upstream evidence

- AndroidFileHost lists LineageOS 13 builds specifically for GT-I8262/arubaslim, including 2017-02-09, 2017-02-17 and 2017-02-21 builds.
- A historical CM13 build log shows kernel/samsung/arubaslim being built with ARM and zImage.
- The stock build properties identify GT-I8262 as arubaslim, MSM8225 and armeabi-v7a.

These references establish the target; they do not make third-party binaries part of SaiOS.
