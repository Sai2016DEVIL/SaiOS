# Flashing outline

1. Back up the phone.
2. Ensure the device is actually GT-I8262, not I8260 or another Galaxy Core.
3. Have a known-good GT-I8262/arubaslim custom recovery compatible with the partition layout.
4. Odin can be used in Samsung Download Mode to install that recovery as a `.tar`/`.tar.md5`.
5. Boot recovery.
6. Make a recovery backup.
7. Wipe the partitions required by the ROM instructions.
8. Install the SaiOS recovery ZIP.
9. Reboot.

A ROM ZIP is not automatically an Odin firmware package. Creating an Odin package requires verified device-specific partition images and a verified PIT/partition map.
