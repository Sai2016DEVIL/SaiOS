# Device notes

GT-I8262 is the dual-SIM Galaxy Core variant. Device codename: arubaslim. Chipset: Qualcomm MSM8225, ARMv7, 1 GB RAM, 480x800 display. Stock software was Android 4.1.2.

SaiOS targets the historically documented CM13/LineageOS 13 arubaslim platform rather than inventing a new kernel interface.
