# SaiOS v2 — Samsung Galaxy Core GT-I8262

This is a complete build workspace for producing a SaiOS v2 ROM for the Samsung Galaxy Core GT-I8262 (codename `arubaslim`). It is intentionally source/build based: no fabricated boot/recovery/system images are included.

## Target
- GT-I8262 (dual SIM)
- Samsung `arubaslim`
- Qualcomm MSM8225 / ARMv7
- 480x800 display
- Android 6.0-era base

## Build
Use a Linux x86_64 machine with the Android 6.0/CM13-era build dependencies. Run:

    ./tools/fetch-sources.sh
    source build/envsetup.sh
    lunch saios_arubaslim-userdebug
    ./tools/build-saios.sh

The scripts fetch the public Android/Lineage-era source and device/kernel candidates, then apply the SaiOS overlay. The exact upstream repository may have moved; the script tries several known candidates and stops rather than silently substituting another device.

## Flashing
The output is a recovery-flashable ROM ZIP when the build succeeds. Odin is normally used for a compatible custom recovery `.tar` on this device; the ROM ZIP itself is flashed from recovery. Do not use PIT/Re-Partition unless you have a device-specific partition map.

## Important
The GT-I8262 has dual-SIM hardware, but SIM service depends on the proprietary modem/RIL stack. Do not assume calls/SMS/mobile data work merely because the ROM boots.
